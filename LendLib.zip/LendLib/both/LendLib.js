lists = new Meteor.Collection('lists');
